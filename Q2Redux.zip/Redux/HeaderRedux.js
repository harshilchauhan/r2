import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom';

const HeaderRedux = () => {
    const [data,setData] = useState([]);

    useEffect(()=>{
        getData()
    },[])
    
    const getData = async () =>{
        try{
            const result = await axios.get('http://localhost:5050/blog/getdistinct')
            setData(result.data);
        }catch(err){
            console.log(err)
        }
    }

  return (
    <div>
      <div className='container'>
        <ul className='list-group list-group-horizontal'>
            <li className='list-group-item'><NavLink to={`/q2/redux/`}>All</NavLink></li>
            {
                data.map((d)=>{
                    return(
                        <li className='list-group-item'><NavLink to={`/q2/redux/${d}`}>{d}</NavLink></li>
                    )
                })
            }
        </ul>
      </div>
    </div>
  )
}

export default HeaderRedux
