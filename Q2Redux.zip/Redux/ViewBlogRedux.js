import React, { useEffect, useState } from 'react'
import NNavbar from '../NNavbar'
import NavbarRedux from './NavbarRedux'
import { useParams } from 'react-router';
import axios from 'axios';
import HeaderRedux from './HeaderRedux';


const ViewBlogRedux = () => {
  const [data,setData] = useState([]);
  const params = useParams();

  useEffect(()=>{
      getData()
  },[params.id])

  const getData =async ()=>{
    try{
        if(params.id){
            const result = await axios.get(`http://localhost:5050/blog/display/${params.id}`)
            setData(result.data)
        }
        else{
            const result = await axios.get(`http://localhost:5050/blog/`)
            setData(result.data)
        }
    }
    catch(err){
        console.log(err);
    }
}

  return (
    <div>
      <hr />
      <NNavbar />
      <hr />
      <NavbarRedux />
      <hr/>
      <HeaderRedux/>
      <div className='container'>
            {data.map((i)=>{
                return(
                    <div className='container bg-light'>
                        <hr/>
                        <div className='row text-start'>
                            <div className='col'>
                                <h1>Blog:{i.blog}</h1>
                            </div>
                        </div>
                        <div className='row text-start'>
                            <div className='col'>
                                <h4>Blog type:{i.blogtype}</h4>
                            </div>
                        </div>
                        <div className='row text-start'>
                            <div className='col'>
                                <h4>Desc:{i.blogdesc}</h4>
                            </div>
                        </div>
                        <div className='row text-start'>
                            <div className='col'>
                                <h4>Author:{i.createby}</h4>
                            </div>
                        </div>
                    </div>
                )
            })}
            </div>
    </div>
  )
}

export default ViewBlogRedux
