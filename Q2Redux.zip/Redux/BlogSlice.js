import { createSlice } from "@reduxjs/toolkit"
import axios from "axios";

const result = axios.get('http://localhost:5050/blog/')
const data = result.data
// const initialState = result.data;

export const BlogSlice = createSlice({
    name:"blog",
    initialState:{
        data
    },
    reducers:{
        AddBlog:(state,action)=>{
            const blog = action.payload.blog;
            const blogtype = action.payload.blogtype;
            const blogdesc = action.payload.blogdesc;
            const createby = action.payload.createby;

            axios.post('http://localhost:5050/blog/addblog',{
                blog,blogtype,blogdesc,createby
            })

        }
    }
})

export const {AddBlog}=BlogSlice.actions;
export default BlogSlice.reducer;