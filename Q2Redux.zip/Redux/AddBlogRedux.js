import React, { useState } from 'react'
import NNavbar from '../NNavbar'
import NavbarRedux from './NavbarRedux'
import { useDispatch } from 'react-redux';
import { AddBlog } from './BlogSlice';

const AddBlogRedux = () => {
  const dispatch = useDispatch();
  const [blogtype, setBlogtype] = useState('');
  const [blog, setBlog] = useState('');
  const [blogdesc, setBlogdesc] = useState('');
  const [createby, setCreateby] = useState('');
  const AddBlogHandler = async () => {
    dispatch(AddBlog({ blogtype, blog, blogdesc, createby }));
    setBlogtype("");
    setBlog("");
    setBlogdesc("");
    setCreateby("");
    alert("Data Inserted");
  }
  return (
    <div>
      <hr />
      <NNavbar />
      <hr />
      <NavbarRedux />
      <div className='container'>
        <div className='m-5'>
          <div className="mb-3">
            <label for="user" className="form-label">Blog Type:</label>
            <input type="text" className="form-control" id="user" value={blogtype} onChange={(e) => setBlogtype(e.target.value)} />
          </div>
          <div className="mb-3">
            <label for="user" className="form-label">Blog Title:</label>
            <input type="text" className="form-control" id="user" value={blog} onChange={(e) => setBlog(e.target.value)} />
          </div>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Blog Desc:</label>
            <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={blogdesc} onChange={(e) => setBlogdesc(e.target.value)} />
          </div>
          <div className="mb-3">
            <label for="user" className="form-label">Author:</label>
            <input type="text" className="form-control" id="user" value={createby} onChange={(e) => setCreateby(e.target.value)} />
          </div>
          <br />
          <button className="btn btn-primary" onClick={AddBlogHandler} >Add Blog</button>

        </div>
      </div>
    </div>
  )
}

export default AddBlogRedux
