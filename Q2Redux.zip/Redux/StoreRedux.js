import { configureStore } from "@reduxjs/toolkit";
import BlogReducer from './BlogSlice';

export const StoreRedux = configureStore({
    reducer:{
        // Counter:CounterReducer,
        blog:BlogReducer
    }
})